import { createClient } from "npm:@supabase/supabase-js@2";

const cors = {"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type"};
const json=(body,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,"Content-Type":"application/json"}});

Deno.serve(async req=>{
  if(req.method==="OPTIONS") return new Response("ok",{headers:cors});
  try{
    const {customer,items}=await req.json();
    if(!customer?.name||!customer?.phone||!customer?.email||!customer?.address||!Array.isArray(items)||!items.length) return json({error:"Invalid checkout data"},400);

    const supabase=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SECRET_KEY")!);
    const ids=items.map((x:any)=>x.product_id).filter(Boolean);
    const {data:products,error}=await supabase.from("products").select("id,name,price,stock,active").in("id",ids);
    if(error) throw error;

    let subtotal=0;
    const serverItems=items.map((item:any)=>{
      if(!item.product_id){
        const price=Number(item.price)||0;
        const quantity=Number(item.quantity)||1;
        subtotal+=price*quantity;
        return {product_id:null,product_name:item.name,unit_price:price,quantity,metadata:item.metadata||null};
      }
      const p=products?.find((x:any)=>x.id===item.product_id);
      if(!p||!p.active||p.stock<Number(item.quantity)) throw new Error(`Product unavailable: ${item.name}`);
      const quantity=Number(item.quantity);
      subtotal+=Number(p.price)*quantity;
      return {product_id:p.id,product_name:p.name,unit_price:Number(p.price),quantity,metadata:item.metadata||null};
    });

    const reference=`EE-${crypto.randomUUID().replaceAll("-","").slice(0,16).toUpperCase()}`;
    const {data:order,error:orderError}=await supabase.from("orders").insert({
      reference,customer_name:customer.name,customer_phone:customer.phone,customer_email:customer.email,
      delivery_address:customer.address,subtotal
    }).select("id,reference").single();
    if(orderError) throw orderError;
    const {error:itemError}=await supabase.from("order_items").insert(serverItems.map((x:any)=>({...x,order_id:order.id})));
    if(itemError) throw itemError;

    const paystack=await fetch("https://api.paystack.co/transaction/initialize",{
      method:"POST",headers:{"Authorization":`Bearer ${Deno.env.get("PAYSTACK_SECRET_KEY")!}`,"Content-Type":"application/json"},
      body:JSON.stringify({email:customer.email,amount:Math.round(subtotal*100),currency:"GHS",reference,metadata:{order_id:order.id}})
    });
    const payment=await paystack.json();
    if(!payment.status) throw new Error(payment.message||"Paystack initialization failed");
    await supabase.from("orders").update({paystack_reference:reference}).eq("id",order.id);
    return json({authorization_url:payment.data.authorization_url,reference});
  }catch(e){console.error(e);return json({error:e instanceof Error?e.message:"Server error"},500)}
});
