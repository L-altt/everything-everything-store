import { createClient } from "npm:@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type"};
Deno.serve(async req=>{
  if(req.method==="OPTIONS")return new Response("ok",{headers:cors});
  try{
    const {reference}=await req.json();
    if(!reference) return new Response(JSON.stringify({error:"Missing reference"}),{status:400,headers:{...cors,"Content-Type":"application/json"}});
    const payment=await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,{headers:{"Authorization":`Bearer ${Deno.env.get("PAYSTACK_SECRET_KEY")!}`}});
    const result=await payment.json();
    if(!result.status) throw new Error(result.message||"Verification failed");
    const supabase=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SECRET_KEY")!);
    if(result.data.status==="success"){
      await supabase.from("orders").update({payment_status:"paid"}).eq("paystack_reference",reference);
      return new Response(JSON.stringify({paid:true}),{headers:{...cors,"Content-Type":"application/json"}});
    }
    await supabase.from("orders").update({payment_status:"failed"}).eq("paystack_reference",reference);
    return new Response(JSON.stringify({paid:false}),{headers:{...cors,"Content-Type":"application/json"}});
  }catch(e){return new Response(JSON.stringify({error:e instanceof Error?e.message:"Verification error"}),{status:500,headers:{...cors,"Content-Type":"application/json"}})}
});
